const {init}=require("./_db");const {getUser,json}=require("./_auth");
exports.handler=async event=>{
 try{const s=getUser(event);if(!s||s.role!=="admin")return json(403,{error:"Admin access required"});const db=await init();
 if(event.httpMethod==="GET"){
  const [[u]] = await db.query("SELECT COUNT(*) c FROM users");const [[t]] = await db.query("SELECT COUNT(*) c FROM tickets");const [[o]] = await db.query("SELECT COUNT(*) c FROM tickets WHERE status IN ('open','processing')");
  const [users]=await db.query("SELECT id,name,email,role,status,created_at FROM users ORDER BY created_at DESC LIMIT 500");
  const [tickets]=await db.query("SELECT t.id,t.subject,t.message,t.status,t.priority,t.created_at,u.email FROM tickets t JOIN users u ON u.id=t.user_id ORDER BY t.created_at DESC LIMIT 500");
  const [ss]=await db.query("SELECT setting_key,setting_value FROM settings");const settings=Object.fromEntries(ss.map(x=>[x.setting_key,x.setting_value]));
  return json(200,{ok:true,stats:{users:u.c,tickets:t.c,open_tickets:o.c},users,tickets,settings});
 }
 if(event.httpMethod==="PUT"){
  const b=JSON.parse(event.body||"{}");
  if(b.action==="toggleUser"){const [[x]]=await db.query("SELECT status,role FROM users WHERE id=?",[Number(b.id)]);if(!x)return json(404,{error:"User not found"});if(x.role==="admin")return json(400,{error:"Admin account cannot be blocked here"});await db.query("UPDATE users SET status=? WHERE id=?",[x.status==="active"?"blocked":"active",Number(b.id)]);return json(200,{ok:true})}
  if(b.action==="ticket"){const allowed=["open","processing","resolved","closed"];if(!allowed.includes(b.status))return json(400,{error:"Invalid status"});await db.query("UPDATE tickets SET status=? WHERE id=?",[b.status,Number(b.id)]);return json(200,{ok:true})}
  if(b.action==="settings"){for(const [k,v] of [["site_name",b.site_name],["announcement",b.announcement],["maintenance",b.maintenance?"1":"0"]])await db.query("INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)",[k,String(v??"")]);return json(200,{ok:true})}
 }
 return json(405,{error:"Method not allowed"});
 }catch(e){console.error(e);return json(500,{error:"Server error"})}
};
