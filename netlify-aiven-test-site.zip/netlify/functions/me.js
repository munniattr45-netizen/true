const {init}=require("./_db");const {getUser,json}=require("./_auth");
exports.handler=async event=>{
 try{const s=getUser(event);if(!s)return json(401,{error:"Not signed in"});const db=await init();
 if(event.httpMethod==="GET"){const [r]=await db.query("SELECT u.id,u.name,u.email,u.role,u.status,u.created_at,(SELECT COUNT(*) FROM tickets t WHERE t.user_id=u.id) ticket_count FROM users u WHERE u.id=?",[s.id]);if(!r.length)return json(404,{error:"User not found"});return json(200,{ok:true,user:r[0]})}
 if(event.httpMethod==="PUT"){const b=JSON.parse(event.body||"{}");const name=String(b.name||"").trim();if(name.length<2)return json(400,{error:"Invalid name"});await db.query("UPDATE users SET name=? WHERE id=?",[name,s.id]);return json(200,{ok:true})}
 return json(405,{error:"Method not allowed"});
 }catch(e){console.error(e);return json(500,{error:"Server error"})}
};
