const mysql = require("mysql2/promise");

let pool;
function getPool(){
  if(!pool){
    pool=mysql.createPool({
      host:process.env.DB_HOST,
      port:Number(process.env.DB_PORT||3306),
      user:process.env.DB_USER,
      password:process.env.DB_PASSWORD,
      database:process.env.DB_NAME||"defaultdb",
      ssl:process.env.DB_SSL==="true"?{rejectUnauthorized:true}:undefined,
      waitForConnections:true,
      connectionLimit:5,
      queueLimit:0
    });
  }
  return pool;
}
async function init(){
 const db=getPool();
 await db.query(`CREATE TABLE IF NOT EXISTS users(
   id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   name VARCHAR(80) NOT NULL,
   email VARCHAR(190) NOT NULL UNIQUE,
   password_hash VARCHAR(255) NOT NULL,
   role ENUM('user','admin') NOT NULL DEFAULT 'user',
   status ENUM('active','blocked') NOT NULL DEFAULT 'active',
   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
   updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
 )`);
 await db.query(`CREATE TABLE IF NOT EXISTS tickets(
   id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
   user_id BIGINT UNSIGNED NOT NULL,
   subject VARCHAR(150) NOT NULL,
   message TEXT NOT NULL,
   status ENUM('open','processing','resolved','closed') NOT NULL DEFAULT 'open',
   priority ENUM('low','normal','high') NOT NULL DEFAULT 'normal',
   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
   updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
   INDEX(user_id)
 )`);
 await db.query(`CREATE TABLE IF NOT EXISTS settings(
   setting_key VARCHAR(80) PRIMARY KEY,
   setting_value TEXT NULL
 )`);
 await db.query(`INSERT IGNORE INTO settings(setting_key,setting_value) VALUES
 ('site_name','NovaDesk'),('announcement','Welcome to the testing portal.'),('maintenance','0')`);
 return db;
}
module.exports={getPool,init};
