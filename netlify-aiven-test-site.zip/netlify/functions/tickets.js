const {init}=require("./_db");const {getUser,json}=require("./_auth");
exports.handler=async event=>{
 try{const s=getUser(event);if(!s)return json(401,{error:"Not signed in"});const db=await init();
 if(event.httpMethod==="GET"){const [r]=await db.query("SELECT id,subject,message,status,priority,created_at,updated_at FROM tickets WHERE user_id=? ORDER BY created_at DESC",[s.id]);return json(200,{ok:true,tickets:r})}
 if(event.httpMethod==="POST"){const b=JSON.parse(event.body||"{}");const subject=String(b.subject||"").trim(),message=String(b.message||"").trim();if(!subject||!message)return json(400,{error:"Subject and message are required."});await db.query("INSERT INTO tickets(user_id,subject,message) VALUES(?,?,?)",[s.id,subject,message]);return json(200,{ok:true})}
 return json(405,{error:"Method not allowed"});
 }catch(e){console.error(e);return json(500,{error:"Server error"})}
};
