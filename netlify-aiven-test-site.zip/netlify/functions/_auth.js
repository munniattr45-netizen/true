const jwt=require("jsonwebtoken");
const secret=()=>process.env.JWT_SECRET;
function cookie(name,value,maxAge=60*60*24*7){return `${name}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;}
function clear(){return "session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0";}
function setSession(user){return cookie("session",jwt.sign({id:user.id,role:user.role},secret(),{expiresIn:"7d"}));}
function getUser(event){
 const raw=(event.headers.cookie||"").split(";").map(x=>x.trim()).find(x=>x.startsWith("session="));
 if(!raw)return null;
 try{return jwt.verify(raw.slice(8),secret())}catch{return null}
}
function json(status,body,headers={}){return{statusCode:status,headers:{"Content-Type":"application/json","Cache-Control":"no-store",...headers},body:JSON.stringify(body)}}
module.exports={setSession,clear,getUser,json};
