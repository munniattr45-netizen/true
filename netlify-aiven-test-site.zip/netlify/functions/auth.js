const bcrypt=require("bcryptjs");const {init}=require("./_db");const {setSession,clear,json}=require("./_auth");
exports.handler=async event=>{
 try{
  const db=await init(); const b=JSON.parse(event.body||"{}"); const action=b.action;
  if(action==="logout")return json(200,{ok:true},{ "Set-Cookie":clear() });
  if(action==="register"){
   const name=String(b.name||"").trim(),email=String(b.email||"").trim().toLowerCase(),password=String(b.password||"");
   if(name.length<2||email.length<5||password.length<8)return json(400,{error:"Name, valid email and 8+ character password are required."});
   const [exists]=await db.query("SELECT id FROM users WHERE email=?",[email]);if(exists.length)return json(409,{error:"Email is already registered."});
   const hash=await bcrypt.hash(password,12);const [r]=await db.query("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",[name,email,hash]);
   const user={id:r.insertId,role:"user"};return json(200,{ok:true},{ "Set-Cookie":setSession(user) });
  }
  if(action==="login"){
   const email=String(b.email||"").trim().toLowerCase();const password=String(b.password||"");
   const [rows]=await db.query("SELECT id,name,email,password_hash,role,status FROM users WHERE email=?",[email]);
   if(!rows.length||!(await bcrypt.compare(password,rows[0].password_hash)))return json(401,{error:"Invalid email or password."});
   if(rows[0].status!=="active")return json(403,{error:"This account is blocked."});
   return json(200,{ok:true},{ "Set-Cookie":setSession(rows[0]) });
  }
  return json(400,{error:"Unknown action."});
 }catch(e){console.error(e);return json(500,{error:"Server error."})}
};
