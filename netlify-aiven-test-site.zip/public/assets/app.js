async function api(path,opts={}){const o={headers:{'Content-Type':'application/json'},credentials:'include',...opts};if(o.body&&typeof o.body!=='string')o.body=JSON.stringify(o.body);try{const r=await fetch(path,o);const d=await r.json().catch(()=>({error:'Invalid server response'}));return {...d,status:r.status,ok:r.ok}}catch(e){return {ok:false,error:'Network error'}}}
function showMsg(x){const e=document.querySelector('#msg');if(e)e.textContent=x||''}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
