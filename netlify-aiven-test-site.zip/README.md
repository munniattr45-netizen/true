# Netlify + Aiven MySQL Testing Website

A production-oriented TESTING starter using:
- Static HTML/CSS/Vanilla JS
- Netlify Functions
- Aiven MySQL
- JWT authentication
- bcrypt password hashing
- User dashboard
- Support tickets
- Admin dashboard with user/ticket/site controls

## 1. Aiven security
Do NOT put the Aiven password in frontend files.
Create these Netlify environment variables:

DB_HOST
DB_PORT
DB_USER
DB_PASSWORD
DB_NAME
DB_SSL=true
JWT_SECRET

Use the values from your Aiven service.

IMPORTANT: The database password was pasted into chat. For safety, rotate/regenerate that Aiven password before using this project publicly.

## 2. Deploy
1. Upload this project to GitHub.
2. Import the repository into Netlify.
3. Build command: leave empty.
4. Publish directory: `public`.
5. Add the environment variables above.
6. Deploy.

The database tables are created automatically on first API request.

## 3. First admin
For testing, register a normal account first. Then in Aiven MySQL run:

UPDATE users SET role='admin' WHERE email='YOUR_EMAIL';

After that, sign out/in and open `/admin`.

For a real production deployment, replace this bootstrap method with a controlled server-side admin provisioning process.

## 4. Routes
/              Landing page
/login.html    Sign in
/register.html Sign up
/home.html     User dashboard
/support.html  Support
/admin         Admin panel
